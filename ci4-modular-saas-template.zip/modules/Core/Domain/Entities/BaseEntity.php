﻿<?php
namespace Modules\Core\Domain\Entities;

use CodeIgniter\Entity\Entity;

class BaseEntity extends Entity {}
